import React, { useState } from 'react';
import { useCasino } from '../../../context/CasinoContext';

/**
 * Game: Goal 2 (goal2)
 * 100% Dedicated Standalone Market Table
 * Exact DOM, class names, and button layout matching production Diamond247 (goal2.html)
 */
export default function Goal2Table() {
  const { roundData, isSuspended, openBetSlip } = useCasino();
  const isMobile = typeof window !== 'undefined' && window.innerWidth < 1200;

  // 1. Who Will Goal Next? (subtype: "player")
  const playersMarket = [
    { sid: 1, nat: 'Cristiano Ronaldo', b: '4.50', bs: '150k', l: '4.80', ls: '150k', min: 100, max: 50000, subtype: 'player' },
    { sid: 2, nat: 'Lionel Messi', b: '4.80', bs: '150k', l: '5.10', ls: '150k', min: 100, max: 50000, subtype: 'player' },
    { sid: 3, nat: 'Robert Lewandowski', b: '5.20', bs: '100k', l: '5.50', ls: '100k', min: 100, max: 50000, subtype: 'player' },
    { sid: 4, nat: 'Karim Benzema', b: '6.00', bs: '80k', l: '6.40', ls: '80k', min: 100, max: 50000, subtype: 'player' },
    { sid: 5, nat: 'Edinson Cavani', b: '7.50', bs: '60k', l: '8.00', ls: '60k', min: 100, max: 50000, subtype: 'player' },
    { sid: 6, nat: 'Luis Suarez', b: '8.00', bs: '50k', l: '8.50', ls: '50k', min: 100, max: 50000, subtype: 'player' },
    { sid: 7, nat: 'Neymar', b: '7.00', bs: '70k', l: '7.50', ls: '70k', min: 100, max: 50000, subtype: 'player' },
    { sid: 8, nat: 'Sergio Aguero', b: '9.00', bs: '40k', l: '9.60', ls: '40k', min: 100, max: 50000, subtype: 'player' },
    { sid: 9, nat: 'Olivier Giroud', b: '10.00', bs: '35k', l: '10.80', ls: '35k', min: 100, max: 50000, subtype: 'player' },
    { sid: 10, nat: 'Mohamed Salah', b: '6.50', bs: '90k', l: '7.00', ls: '90k', min: 100, max: 50000, subtype: 'player' },
    { sid: 11, nat: 'Kylian Mbappe', b: '5.00', bs: '120k', l: '5.30', ls: '120k', min: 100, max: 50000, subtype: 'player' },
    { sid: 12, nat: 'No Goal', b: '3.20', bs: '200k', l: '3.40', ls: '200k', min: 100, max: 25000, subtype: 'player' },
  ];

  // 2. Method Of Next Goal (subtype: "method")
  const methodsMarket = [
    { sid: 21, nat: 'Shot Goal', b: '1.85', bs: '250k', l: '1.92', ls: '250k', min: 100, max: 50000, subtype: 'method' },
    { sid: 22, nat: 'Header Goal', b: '4.50', bs: '80k', l: '4.80', ls: '80k', min: 100, max: 50000, subtype: 'method' },
    { sid: 23, nat: 'Penalty Goal', b: '6.00', bs: '50k', l: '6.50', ls: '50k', min: 100, max: 50000, subtype: 'method' },
    { sid: 24, nat: 'Free Kick Goal', b: '12.00', bs: '30k', l: '13.00', ls: '30k', min: 100, max: 50000, subtype: 'method' },
    { sid: 25, nat: 'No Goal', b: '3.20', bs: '200k', l: '3.40', ls: '200k', min: 100, max: 25000, subtype: 'method' },
  ];

  // 3. Method Of Combination Goal (subtype: "combo")
  const combosMarket = [
    { sid: 121, nat: 'Cristiano Ronaldo and Shot Goal', b: '7.50', min: 100, max: 25000 },
    { sid: 122, nat: 'Cristiano Ronaldo and Header Goal', b: '15.00', min: 100, max: 10000 },
    { sid: 123, nat: 'Cristiano Ronaldo and Penalty Goal', b: '18.00', min: 100, max: 10000 },
    { sid: 124, nat: 'Cristiano Ronaldo and Free Kick Goal', b: '25.00', min: 100, max: 10000 },
    { sid: 125, nat: 'Cristiano Ronaldo and No Goal', b: '35.00', min: 100, max: 10000 },

    { sid: 221, nat: 'Lionel Messi and Shot Goal', b: '8.00', min: 100, max: 25000 },
    { sid: 222, nat: 'Lionel Messi and Header Goal', b: '20.00', min: 100, max: 10000 },
    { sid: 223, nat: 'Lionel Messi and Penalty Goal', b: '16.00', min: 100, max: 10000 },
    { sid: 224, nat: 'Lionel Messi and Free Kick Goal', b: '22.00', min: 100, max: 10000 },
    { sid: 225, nat: 'Lionel Messi and No Goal', b: '35.00', min: 100, max: 10000 },

    { sid: 321, nat: 'Robert Lewandowski and Shot Goal', b: '8.50', min: 100, max: 25000 },
    { sid: 322, nat: 'Robert Lewandowski and Header Goal', b: '14.00', min: 100, max: 10000 },
    { sid: 323, nat: 'Robert Lewandowski and Penalty Goal', b: '18.00', min: 100, max: 10000 },
    { sid: 324, nat: 'Robert Lewandowski and Free Kick Goal', b: '30.00', min: 100, max: 10000 },
    { sid: 325, nat: 'Robert Lewandowski and No Goal', b: '40.00', min: 100, max: 10000 },

    { sid: 1121, nat: 'Kylian Mbappe and Shot Goal', b: '8.00', min: 100, max: 25000 },
    { sid: 1122, nat: 'Kylian Mbappe and Header Goal', b: '18.00', min: 100, max: 10000 },
    { sid: 1123, nat: 'Kylian Mbappe and Penalty Goal', b: '18.00', min: 100, max: 10000 },
    { sid: 1124, nat: 'Kylian Mbappe and Free Kick Goal', b: '28.00', min: 100, max: 10000 },
    { sid: 1125, nat: 'Kylian Mbappe and No Goal', b: '40.00', min: 100, max: 10000 },

    { sid: 1021, nat: 'Mohamed Salah and Shot Goal', b: '10.00', min: 100, max: 25000 },
    { sid: 1022, nat: 'Mohamed Salah and Header Goal', b: '22.00', min: 100, max: 10000 },
    { sid: 1023, nat: 'Mohamed Salah and Penalty Goal', b: '20.00', min: 100, max: 10000 },
    { sid: 1024, nat: 'Mohamed Salah and Free Kick Goal', b: '30.00', min: 100, max: 10000 },
    { sid: 1025, nat: 'Mohamed Salah and No Goal', b: '45.00', min: 100, max: 10000 },

    { sid: 721, nat: 'Neymar and Shot Goal', b: '11.00', min: 100, max: 25000 },
    { sid: 722, nat: 'Neymar and Header Goal', b: '25.00', min: 100, max: 10000 },
    { sid: 723, nat: 'Neymar and Penalty Goal', b: '18.00', min: 100, max: 10000 },
    { sid: 724, nat: 'Neymar and Free Kick Goal', b: '24.00', min: 100, max: 10000 },
    { sid: 725, nat: 'Neymar and No Goal', b: '45.00', min: 100, max: 10000 },
  ];

  return (
    <div className="casino-detail detail-page-container position-relative">
      {/* ============================================================== */}
      {/* 1. Market: Who Will Goal Next? (market-6)                     */}
      {/* ============================================================== */}
      <div className="game-market market-6 container-fluid container-fluid-5">
        <div className="market-title row row5">Who Will Goal Next?</div>
        <div className="market-header row row5">
          <div className="col-12 col-md-12 d-none d-md-block">
            <div className="market-row">
              <div className="market-nation-detail"></div>
              <div className="market-odd-box back"><b>Back</b></div>
              <div className="market-odd-box lay"><b>Lay</b></div>
              <div className="fancy-min-max-box"></div>
            </div>
          </div>
          <div className="col-12 col-md-4 d-md-none">
            <div className="market-row">
              <div className="market-nation-detail"></div>
              <div className="market-odd-box back"><b>Back</b></div>
              <div className="market-odd-box lay"><b>Lay</b></div>
              <div className="fancy-min-max-box"></div>
            </div>
          </div>
        </div>

        <div className="market-body row">
          {playersMarket.map((item) => (
            <div key={item.sid} className="col-12 col-md-12">
              <div className="fancy-market" data-title={isSuspended ? 'SUSPENDED' : 'OPEN'}>
                <div className="market-row">
                  <div className="market-nation-detail">
                    <span className="market-nation-name pointer">{item.nat}</span>
                  </div>

                  <div className={`blb-box goal2-odds-box ${isSuspended ? 'suspended-box' : ''}`}>
                    <div
                      className="market-odd-box back"
                      onClick={isSuspended ? undefined : () => openBetSlip(item.nat, item.b, 'back', isMobile)}
                      style={{ cursor: isSuspended ? 'not-allowed' : 'pointer' }}
                    >
                      <b>{isSuspended ? '-' : item.b}</b>
                      <span>{isSuspended ? '' : item.bs}</span>
                    </div>
                    <div
                      className="market-odd-box lay"
                      onClick={isSuspended ? undefined : () => openBetSlip(item.nat, item.l, 'lay', isMobile)}
                      style={{ cursor: isSuspended ? 'not-allowed' : 'pointer' }}
                    >
                      <b>{isSuspended ? '-' : item.l}</b>
                      <span>{isSuspended ? '' : item.ls}</span>
                    </div>
                  </div>

                  <div className="fancy-min-max-box">
                    <div className="fancy-min-max">
                      <span className="w-100 d-block">Min: {item.min}</span>
                      <span className="w-100 d-block">Max: {item.max >= 1000 ? `${item.max / 1000}k` : item.max}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ============================================================== */}
      {/* 2. Market: Method Of Next Goal (market-6)                     */}
      {/* ============================================================== */}
      <div className="game-market market-6 container-fluid container-fluid-5 mt-3">
        <div className="market-title row row5">Method Of Next Goal</div>
        <div className="market-header row row5">
          <div className="col-12 col-md-12 d-none d-md-block">
            <div className="market-row">
              <div className="market-nation-detail"></div>
              <div className="market-odd-box back"><b>Back</b></div>
              <div className="market-odd-box lay"><b>Lay</b></div>
              <div className="fancy-min-max-box"></div>
            </div>
          </div>
          <div className="col-12 col-md-4 d-md-none">
            <div className="market-row">
              <div className="market-nation-detail"></div>
              <div className="market-odd-box back"><b>Back</b></div>
              <div className="market-odd-box lay"><b>Lay</b></div>
              <div className="fancy-min-max-box"></div>
            </div>
          </div>
        </div>

        <div className="market-body row">
          {methodsMarket.map((item) => (
            <div key={item.sid} className="col-12 col-md-12">
              <div className="fancy-market" data-title={isSuspended ? 'SUSPENDED' : 'OPEN'}>
                <div className="market-row">
                  <div className="market-nation-detail">
                    <span className="market-nation-name pointer">{item.nat}</span>
                  </div>

                  <div className={`blb-box goal2-odds-box ${isSuspended ? 'suspended-box' : ''}`}>
                    <div
                      className="market-odd-box back"
                      onClick={isSuspended ? undefined : () => openBetSlip(item.nat, item.b, 'back', isMobile)}
                      style={{ cursor: isSuspended ? 'not-allowed' : 'pointer' }}
                    >
                      <b>{isSuspended ? '-' : item.b}</b>
                      <span>{isSuspended ? '' : item.bs}</span>
                    </div>
                    <div
                      className="market-odd-box lay"
                      onClick={isSuspended ? undefined : () => openBetSlip(item.nat, item.l, 'lay', isMobile)}
                      style={{ cursor: isSuspended ? 'not-allowed' : 'pointer' }}
                    >
                      <b>{isSuspended ? '-' : item.l}</b>
                      <span>{isSuspended ? '' : item.ls}</span>
                    </div>
                  </div>

                  <div className="fancy-min-max-box">
                    <div className="fancy-min-max">
                      <span className="w-100 d-block">Min: {item.min}</span>
                      <span className="w-100 d-block">Max: {item.max >= 1000 ? `${item.max / 1000}k` : item.max}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ============================================================== */}
      {/* 3. Market: Method Of Combination Goal (market-comb)           */}
      {/* ============================================================== */}
      <div className="game-market market-comb container-fluid container-fluid-5 mt-3">
        <div className="market-title row row5">Method Of Combination Goal</div>
        <div className="market-header row row5">
          <div className="col-6 col-md-6 d-none d-md-block">
            <div className="market-row">
              <div className="market-nation-detail"></div>
              <div className="market-odd-box back"><b>Back</b></div>
              <div className="fancy-min-max-box"></div>
            </div>
          </div>
          <div className="col-6 col-md-6 d-none d-md-block">
            <div className="market-row">
              <div className="market-nation-detail"></div>
              <div className="market-odd-box back"><b>Back</b></div>
              <div className="fancy-min-max-box"></div>
            </div>
          </div>
          <div className="col-6 col-md-4 d-md-none">
            <div className="market-row">
              <div className="market-nation-detail"></div>
              <div className="market-odd-box back"><b>Back</b></div>
            </div>
          </div>
          <div className="col-6 col-md-4 d-md-none">
            <div className="market-row">
              <div className="market-nation-detail"></div>
              <div className="market-odd-box back"><b>Back</b></div>
            </div>
          </div>
        </div>

        <div className="market-body row row5">
          {combosMarket.map((item) => (
            <div key={item.sid} className="col-6 col-md-6">
              <div className="fancy-market" data-title={isSuspended ? 'SUSPENDED' : 'OPEN'}>
                <div className="market-row">
                  <div className="market-nation-detail">
                    <span className="market-nation-name pointer">{item.nat}</span>
                  </div>

                  <div className={`blb-box ${isSuspended ? 'suspended-box' : ''}`}>
                    <div
                      className="market-odd-box back"
                      onClick={isSuspended ? undefined : () => openBetSlip(item.nat, item.b, 'back', isMobile)}
                      style={{ cursor: isSuspended ? 'not-allowed' : 'pointer' }}
                    >
                      <b>{isSuspended ? '-' : item.b}</b>
                    </div>
                  </div>

                  <div className="fancy-min-max-box d-none d-md-flex">
                    <div className="fancy-min-max">
                      <span className="w-100 d-block">Min: {item.min}</span>
                      <span className="w-100 d-block">Max: {item.max >= 1000 ? `${item.max / 1000}k` : item.max}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Remarks Scrolling Bar */}
      {roundData?.remark && (
        <div className="casino-remark mt-2">
          <marquee scrollamount="3">{roundData.remark}</marquee>
        </div>
      )}
    </div>
  );
}

